package hafsa;

import java.util.Scanner;

public class ClassManagementTest {
    public static void main(String[] args) {
        // Adding sample data
        addSampleData();

        // Start the main interface
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Class Management System");
            System.out.println("1. Manage Students");
            System.out.println("2. Manage Teachers");
            System.out.println("3. Manage Admins");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    StudentManagement.manageStudents(scanner);
                    break;
                case 2:
                    TeacherManagement.manageTeachers(scanner);
                    break;
                case 3:
                    AdminManagement.manageAdmins(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addSampleData() {
        StudentManagement.addSampleStudents();
        TeacherManagement.addSampleTeachers();
        AdminManagement.addSampleAdmins();
    }
}