package hafsa;

public class Admin extends Person {
    public Admin(String id, String name, int age, String nationality) {
        super(id, name, age, nationality);
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
    }
}

