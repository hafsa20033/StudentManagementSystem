package hafsa;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TeacherManagement {
    private static List<Teacher> teachers = new ArrayList<>();
	private static Teacher newTeacher;

    public static void manageTeachers(Scanner scanner) {
        while (true) {
            System.out.println("Teacher Management");
            System.out.println("1. View All Teachers");
            System.out.println("2. Search Teacher by ID");
            System.out.println("3. Add Teacher");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewAllTeachers();
                    break;
                case 2:
                    searchTeacherById(scanner);
                    break;
                case 3:
                    addTeacher(scanner);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void viewAllTeachers() {
        System.out.println("Viewing All Teachers:");
        for (Teacher teacher : teachers) {
            teacher.displayDetails();
            System.out.println("-------------------");
        }
    }

    private static void searchTeacherById(Scanner scanner) {
        System.out.print("Enter teacher ID: ");
        String id = scanner.nextLine();
        for (Teacher teacher : teachers) {
            if (teacher.id.equals(id)) {
                teacher.displayDetails();
                return;
            }
        }
        System.out.println("Teacher not found.");
    }

    private static void addTeacher(Scanner scanner) {
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter name: "); String name = scanner.nextLine(); System.out.print("Enter age: ");
        int age = scanner.nextInt(); scanner.nextLine(); // Consume newline System.out.print("Enter nationality: ");
        String nationality = scanner.nextLine(); System.out.print("Enter subject: "); String subject = scanner.nextLine();
        System.out.print("Enter years of experience: "); int yearsOfExperience = scanner.nextInt(); scanner.nextLine(); 
        // Consume newline Teacher newTeacher = new Teacher(id, name, age, nationality, subject, yearsOfExperience);
        teachers.add(newTeacher); System.out.println("Teacher added successfully.");
        } public static void addSampleTeachers() { teachers.add(new Teacher("T1", "Mr. Smith", 45, "UK", "Mathematics", 20));
        teachers.add(new Teacher("T2", "Ms. Johnson", 39, "USA", "Science", 15));
        teachers.add(new Teacher("T3", "Mr. Brown", 50, "Canada", "History", 25));
        teachers.add(new Teacher("T4", "Ms. Davis", 42, "Australia", "English", 18));
        teachers.add(new Teacher("T5", "Mr. Wilson", 38, "New Zealand", "Physical Education", 12)); } }