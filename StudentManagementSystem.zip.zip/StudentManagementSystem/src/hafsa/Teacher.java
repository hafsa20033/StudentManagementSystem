package hafsa;

public class Teacher extends Person {
    String subject;
    int yearsOfExperience;

    public Teacher(String id, String name, int age, String nationality, String subject, int yearsOfExperience) {
        super(id, name, age, nationality);
        this.subject = subject;
        this.yearsOfExperience = yearsOfExperience;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Subject: " + subject);
        System.out.println("Years of Experience: " + yearsOfExperience);
    }
}