package hafsa;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AdminManagement {
    private static List<Admin> admins = new ArrayList<>();

    public static void manageAdmins(Scanner scanner) {
        while (true) {
            System.out.println("Admin Management");
            System.out.println("1. View All Admins");
            System.out.println("2. Search Admin by ID");
            System.out.println("3. Add Admin");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewAllAdmins();
                    break;
                case 2:
                    searchAdminById(scanner);
                    break;
                case 3:
                    addAdmin(scanner);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void viewAllAdmins() {
        System.out.println("Viewing All Admins:");
        for (Admin admin : admins) {
            admin.displayDetails();
            System.out.println("-------------------");
        }
    }

    private static void searchAdminById(Scanner scanner) {
        System.out.print("Enter admin ID: ");
        String id = scanner.nextLine();
        for (Admin admin : admins) {
            if (admin.id.equals(id)) {
                admin.displayDetails();
                return;
            }
        }
        System.out.println("Admin not found.");
    }

    private static void addAdmin(Scanner scanner) {
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter age: "); int age = scanner.nextInt(); scanner.nextLine();
        String nationality = null;
		// Consume newline System.out.print("Enter nationality:"); String nationality = scanner.nextLine();
        Admin newAdmin = new Admin(id, name, age, nationality); admins.add(newAdmin);
        System.out.println("Admin added successfully.");
        }
    
    public static void addSampleAdmins() { admins.add(new Admin("A1", "Admin1", 35, "Country1"));
        admins.add(new Admin("A2", "Admin2", 40, "Country2")); 
        } 
    }     