package hafsa;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentManagement {
    private static List<Student> students = new ArrayList<>();

    public static void manageStudents(Scanner scanner) {
        while (true) {
            System.out.println("Student Management");
            System.out.println("1. View All Students");
            System.out.println("2. Search Student by ID");
            System.out.println("3. Add Student");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewAllStudents();
                    break;
                case 2:
                    searchStudentById(scanner);
                    break;
                case 3:
                    addStudent(scanner);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void viewAllStudents() {
        System.out.println("Viewing All Students:");
        for (Student student : students) {
            student.displayDetails();
            System.out.println("-------------------");
        }
    }

    private static void searchStudentById(Scanner scanner) {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();
        for (Student student : students) {
            if (student.id.equals(id)) {
                student.displayDetails();
                return;
            }
        }
        System.out.println("Student not found.");
    }

    private static void addStudent(Scanner scanner) {
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter name: "); String name = scanner.nextLine(); System.out.print("Enter age: ");
        int age = scanner.nextInt(); scanner.nextLine(); // Consume newline System.out.print("Enter nationality: ");
        String nationality = scanner.nextLine(); System.out.print("Enter Chinese scores: ");
        int chineseScores = scanner.nextInt(); System.out.print("Enter Java scores: ");
        int javaScores = scanner.nextInt(); scanner.nextLine(); // Consume newline Student newStudent = new Student(id, name, age, nationality, chineseScores, javaScores); students.add(newStudent);
        System.out.println("Student added successfully."); }
    public static void addSampleStudents() { for (int i = 1; i <= 15; i++) { students.add(new Student("S" + i, "Student" + i, 20, "Country" + i, 80 + i, 70 + i)); 
        }
    }
}
       
        