package hafsa;

public class Student extends Person {
    int chineseScores;
    int javaScores;

    public Student(String id, String name, int age, String nationality, int chineseScores, int javaScores) {
        super(id, name, age, nationality);
        this.chineseScores = chineseScores;
        this.javaScores = javaScores;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Chinese Scores: " + chineseScores);
        System.out.println("Java Scores: " + javaScores);
    }
}